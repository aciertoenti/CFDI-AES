import { useState } from "react";

// ─── Design tokens ────────────────────────────────────────────────────────────
const colors = {
  primary: "#0A2540",
  accent: "#00C896",
  accentSoft: "#E6FAF5",
  accentBorder: "#00A87E",
  surface: "#F7F9FC",
  card: "#FFFFFF",
  border: "#E4E9F0",
  textPrimary: "#0A2540",
  textSecondary: "#5A6B7E",
  textMuted: "#8A9BB0",
  danger: "#E53E3E",
  dangerSoft: "#FFF5F5",
  warning: "#DD6B20",
  warningSoft: "#FFFAF0",
  info: "#2B6CB0",
  infoSoft: "#EBF8FF",
};

// ─── Mock data ─────────────────────────────────────────────────────────────────
const mockFacturas = [
  { folio: "A-0001", receptor: "Comercial Mexicana SA", total: 58400, fecha: "2025-05-10", estado: "Vigente", uuid: "ABC1-DEF2-GHI3-JKL4" },
  { folio: "A-0002", receptor: "Grupo Industrial FEMSA", total: 124750, fecha: "2025-05-12", estado: "Vigente", uuid: "MNO5-PQR6-STU7-VWX8" },
  { folio: "A-0003", receptor: "Tiendas Chedraui SA", total: 9800, fecha: "2025-05-14", estado: "Cancelada", uuid: "YZA9-BCD0-EFG1-HIJ2" },
  { folio: "A-0004", receptor: "OXXO Gas SA de CV", total: 32100, fecha: "2025-05-16", estado: "Vigente", uuid: "KLM3-NOP4-QRS5-TUV6" },
  { folio: "A-0005", receptor: "Coppel SA de CV", total: 77600, fecha: "2025-05-19", estado: "Pendiente", uuid: "WXY7-ZAB8-CDE9-FGH0" },
];

const mockClientes = [
  { nombre: "Comercial Mexicana SA", rfc: "CME900101AA1", email: "cfdi@comer.mx", credito: 500000 },
  { nombre: "Grupo Industrial FEMSA", rfc: "GIF850601BB2", email: "facturas@femsa.mx", credito: 2000000 },
  { nombre: "Tiendas Chedraui SA", rfc: "TCH780401CC3", email: "pagos@chedraui.mx", credito: 800000 },
  { nombre: "OXXO Gas SA de CV", rfc: "OGS920301DD4", email: "fiscal@oxxo.mx", credito: 350000 },
];

const mockEmisor = { razon: "Distribuidora Nacional SA de CV", rfc: "DNS010101AAA", regimen: "601 – General de Ley Personas Morales", cp: "06600", csd: "Activo" };

const navItems = [
  { id: "facturas", label: "Mis Facturas", icon: "📄", children: ["nueva", "generadas", "recibidas", "reporte"] },
  { id: "admin", label: "Administración", icon: "⚙️", children: ["emisores", "clientes", "usuarios", "series", "config"] },
  { id: "addenda", label: "Addenda AES", icon: "🔗", children: [] },
];

const fmt = (n) => new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(n);

// ─── Components ────────────────────────────────────────────────────────────────
function Badge({ estado }) {
  const map = {
    Vigente: { bg: "#E6FAF5", color: "#0A6B4A", label: "Vigente" },
    Cancelada: { bg: "#FFF5F5", color: "#9B2C2C", label: "Cancelada" },
    Pendiente: { bg: "#FFFAF0", color: "#744210", label: "Pendiente" },
  };
  const s = map[estado] || map.Pendiente;
  return (
    <span style={{ background: s.bg, color: s.color, fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 20, letterSpacing: "0.02em" }}>
      {s.label}
    </span>
  );
}

function StatCard({ label, value, sub, accent }) {
  return (
    <div style={{ background: accent ? colors.primary : colors.card, border: `1px solid ${accent ? "transparent" : colors.border}`, borderRadius: 12, padding: "18px 20px", flex: 1, minWidth: 140 }}>
      <div style={{ fontSize: 12, color: accent ? "rgba(255,255,255,0.6)" : colors.textMuted, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.06em" }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 700, color: accent ? colors.accent : colors.textPrimary, lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: accent ? "rgba(255,255,255,0.5)" : colors.textMuted, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

// ─── Views ─────────────────────────────────────────────────────────────────────
function NuevaFactura() {
  const [form, setForm] = useState({ receptor: "", rfc: "", concepto: "", cantidad: "", precio: "", iva: "16" });
  const subtotal = (parseFloat(form.cantidad) || 0) * (parseFloat(form.precio) || 0);
  const total = subtotal * (1 + parseFloat(form.iva) / 100);

  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 700, color: colors.textPrimary, marginBottom: 6 }}>Nueva Factura CFDI 4.0</h2>
      <p style={{ color: colors.textSecondary, marginBottom: 28, fontSize: 14 }}>Completa los datos para generar y timbrar ante el SAT.</p>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        {/* Emisor */}
        <div style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: 12, padding: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: colors.accent, letterSpacing: "0.08em", marginBottom: 14, textTransform: "uppercase" }}>Emisor</div>
          {[["Razón social", mockEmisor.razon, true], ["RFC", mockEmisor.rfc, true], ["Régimen fiscal", mockEmisor.regimen, true]].map(([l, v, ro]) => (
            <div key={l} style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: colors.textSecondary, display: "block", marginBottom: 4 }}>{l}</label>
              <input value={v} readOnly={ro} style={{ width: "100%", border: `1px solid ${colors.border}`, borderRadius: 8, padding: "9px 12px", fontSize: 13, color: colors.textPrimary, background: ro ? colors.surface : "#fff", boxSizing: "border-box" }} />
            </div>
          ))}
        </div>
        {/* Receptor */}
        <div style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: 12, padding: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: colors.accent, letterSpacing: "0.08em", marginBottom: 14, textTransform: "uppercase" }}>Receptor</div>
          {[["Nombre / Razón social", "receptor"], ["RFC", "rfc"]].map(([l, k]) => (
            <div key={k} style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: colors.textSecondary, display: "block", marginBottom: 4 }}>{l}</label>
              <input value={form[k]} onChange={e => setForm({ ...form, [k]: e.target.value })} placeholder={`Ingresa ${l.toLowerCase()}`}
                style={{ width: "100%", border: `1px solid ${colors.border}`, borderRadius: 8, padding: "9px 12px", fontSize: 13, color: colors.textPrimary, background: "#fff", boxSizing: "border-box" }} />
            </div>
          ))}
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: colors.textSecondary, display: "block", marginBottom: 4 }}>Uso CFDI</label>
            <select style={{ width: "100%", border: `1px solid ${colors.border}`, borderRadius: 8, padding: "9px 12px", fontSize: 13, color: colors.textPrimary, background: "#fff", boxSizing: "border-box" }}>
              <option>G03 – Gastos en general</option>
              <option>G01 – Adquisición de mercancias</option>
              <option>I01 – Construcciones</option>
              <option>P01 – Por definir</option>
            </select>
          </div>
        </div>
        {/* Conceptos */}
        <div style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: 12, padding: 20, gridColumn: "1 / -1" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: colors.accent, letterSpacing: "0.08em", marginBottom: 14, textTransform: "uppercase" }}>Conceptos</div>
          <div style={{ display: "grid", gridTemplateColumns: "3fr 1fr 1fr 1fr", gap: 12, marginBottom: 12 }}>
            {[["Descripción", "concepto"], ["Cantidad", "cantidad"], ["Precio unitario", "precio"], ["IVA %", "iva"]].map(([l, k]) => (
              <div key={k}>
                <label style={{ fontSize: 12, color: colors.textSecondary, display: "block", marginBottom: 4 }}>{l}</label>
                <input type={k === "concepto" ? "text" : "number"} value={form[k]} onChange={e => setForm({ ...form, [k]: e.target.value })} placeholder={l}
                  style={{ width: "100%", border: `1px solid ${colors.border}`, borderRadius: 8, padding: "9px 12px", fontSize: 13, color: colors.textPrimary, background: "#fff", boxSizing: "border-box" }} />
              </div>
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 32, padding: "14px 0 0", borderTop: `1px solid ${colors.border}` }}>
            {[["Subtotal", subtotal], ["IVA", subtotal * (parseFloat(form.iva) / 100)], ["Total", total]].map(([l, v]) => (
              <div key={l} style={{ textAlign: "right" }}>
                <div style={{ fontSize: 12, color: colors.textMuted }}>{l}</div>
                <div style={{ fontSize: l === "Total" ? 20 : 15, fontWeight: l === "Total" ? 700 : 500, color: l === "Total" ? colors.accent : colors.textPrimary }}>{fmt(v)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div style={{ marginTop: 20, display: "flex", gap: 12 }}>
        <button onClick={() => alert("Conectar con microservicio :8001 → POST /facturas/timbrar")}
          style={{ background: colors.accent, color: "#fff", border: "none", borderRadius: 8, padding: "12px 28px", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
          Timbrar con PAC →
        </button>
        <button style={{ background: "transparent", color: colors.textSecondary, border: `1px solid ${colors.border}`, borderRadius: 8, padding: "12px 24px", fontSize: 14, cursor: "pointer" }}>
          Guardar borrador
        </button>
      </div>
    </div>
  );
}

function FacturasGeneradas() {
  const [search, setSearch] = useState("");
  const filtered = mockFacturas.filter(f => f.receptor.toLowerCase().includes(search.toLowerCase()) || f.folio.includes(search));
  const total = filtered.filter(f => f.estado === "Vigente").reduce((s, f) => s + f.total, 0);

  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 700, color: colors.textPrimary, marginBottom: 20 }}>Facturas Generadas</h2>
      <div style={{ display: "flex", gap: 16, marginBottom: 24, flexWrap: "wrap" }}>
        <StatCard label="Total emitido" value={fmt(mockFacturas.reduce((s, f) => s + f.total, 0))} accent />
        <StatCard label="Vigentes" value={mockFacturas.filter(f => f.estado === "Vigente").length} sub={`${fmt(total)} facturado`} />
        <StatCard label="Canceladas" value={mockFacturas.filter(f => f.estado === "Cancelada").length} />
        <StatCard label="Pendientes" value={mockFacturas.filter(f => f.estado === "Pendiente").length} />
      </div>
      <div style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: 12, overflow: "hidden" }}>
        <div style={{ padding: "14px 20px", borderBottom: `1px solid ${colors.border}`, display: "flex", alignItems: "center", gap: 12 }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por folio o receptor…"
            style={{ flex: 1, border: `1px solid ${colors.border}`, borderRadius: 8, padding: "8px 14px", fontSize: 13, color: colors.textPrimary, background: colors.surface }} />
          <button onClick={() => alert("GET /facturas?format=xml")} style={{ background: "transparent", border: `1px solid ${colors.border}`, borderRadius: 8, padding: "8px 16px", fontSize: 13, color: colors.textSecondary, cursor: "pointer" }}>
            Exportar XML
          </button>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: colors.surface }}>
              {["Folio", "Receptor", "Fecha", "Total", "Estado", "Acciones"].map(h => (
                <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: colors.textMuted, textTransform: "uppercase", letterSpacing: "0.06em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((f, i) => (
              <tr key={f.folio} style={{ borderTop: `1px solid ${colors.border}`, background: i % 2 === 0 ? "#fff" : colors.surface }}>
                <td style={{ padding: "12px 16px", fontSize: 13, fontWeight: 600, color: colors.primary, fontFamily: "monospace" }}>{f.folio}</td>
                <td style={{ padding: "12px 16px", fontSize: 13, color: colors.textPrimary }}>{f.receptor}</td>
                <td style={{ padding: "12px 16px", fontSize: 13, color: colors.textSecondary }}>{f.fecha}</td>
                <td style={{ padding: "12px 16px", fontSize: 13, fontWeight: 600, color: colors.textPrimary }}>{fmt(f.total)}</td>
                <td style={{ padding: "12px 16px" }}><Badge estado={f.estado} /></td>
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button onClick={() => alert(`GET /facturas/${f.uuid}/xml`)} style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, border: `1px solid ${colors.border}`, background: "transparent", cursor: "pointer", color: colors.textSecondary }}>XML</button>
                    <button onClick={() => alert(`GET /facturas/${f.uuid}/pdf`)} style={{ fontSize: 11, padding: "4px 10px", borderRadius: 6, border: `1px solid ${colors.border}`, background: "transparent", cursor: "pointer", color: colors.textSecondary }}>PDF</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Clientes() {
  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 700, color: colors.textPrimary, marginBottom: 20 }}>Clientes</h2>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
        <button onClick={() => alert("POST /admin/clientes")} style={{ background: colors.accent, color: "#fff", border: "none", borderRadius: 8, padding: "10px 20px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
          + Nuevo cliente
        </button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {mockClientes.map(c => (
          <div key={c.rfc} style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: 12, padding: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600, color: colors.textPrimary }}>{c.nombre}</div>
                <div style={{ fontSize: 12, color: colors.textMuted, fontFamily: "monospace", marginTop: 2 }}>{c.rfc}</div>
              </div>
              <div style={{ background: colors.accentSoft, color: colors.accentBorder, fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 20 }}>Activo</div>
            </div>
            <div style={{ fontSize: 13, color: colors.textSecondary, marginBottom: 8 }}>✉ {c.email}</div>
            <div style={{ fontSize: 13, color: colors.textSecondary }}>Crédito: <strong style={{ color: colors.textPrimary }}>{fmt(c.credito)}</strong></div>
            <div style={{ marginTop: 14, display: "flex", gap: 8 }}>
              <button onClick={() => alert(`GET /admin/clientes/${c.rfc}`)} style={{ fontSize: 12, padding: "6px 14px", borderRadius: 7, border: `1px solid ${colors.border}`, background: "transparent", cursor: "pointer", color: colors.textSecondary }}>Editar</button>
              <button onClick={() => alert(`GET /facturas?receptor=${c.rfc}`)} style={{ fontSize: 12, padding: "6px 14px", borderRadius: 7, border: `1px solid ${colors.accentBorder}`, background: colors.accentSoft, cursor: "pointer", color: colors.accentBorder }}>Ver facturas</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Emisores() {
  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 700, color: colors.textPrimary, marginBottom: 20 }}>Emisores</h2>
      <div style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: 12, padding: 24 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20 }}>
          <div style={{ width: 52, height: 52, borderRadius: 12, background: colors.primary, display: "flex", alignItems: "center", justifyContent: "center", color: colors.accent, fontWeight: 700, fontSize: 18 }}>DN</div>
          <div>
            <div style={{ fontSize: 17, fontWeight: 700, color: colors.textPrimary }}>{mockEmisor.razon}</div>
            <div style={{ fontSize: 13, color: colors.textMuted, fontFamily: "monospace" }}>{mockEmisor.rfc}</div>
          </div>
          <div style={{ marginLeft: "auto", background: colors.accentSoft, color: colors.accentBorder, fontSize: 12, fontWeight: 600, padding: "4px 14px", borderRadius: 20 }}>CSD {mockEmisor.csd}</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          {[["Régimen fiscal", mockEmisor.regimen], ["Código postal", mockEmisor.cp], ["RFC", mockEmisor.rfc], ["CSD", mockEmisor.csd]].map(([l, v]) => (
            <div key={l} style={{ background: colors.surface, borderRadius: 8, padding: "12px 16px" }}>
              <div style={{ fontSize: 11, color: colors.textMuted, marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.06em" }}>{l}</div>
              <div style={{ fontSize: 14, fontWeight: 500, color: colors.textPrimary }}>{v}</div>
            </div>
          ))}
        </div>
        <button onClick={() => alert("PUT /admin/emisores/:id")} style={{ marginTop: 16, background: "transparent", border: `1px solid ${colors.border}`, borderRadius: 8, padding: "10px 20px", fontSize: 13, cursor: "pointer", color: colors.textSecondary }}>
          Actualizar CSD / datos fiscales
        </button>
      </div>
    </div>
  );
}

function AddendaAES() {
  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 700, color: colors.textPrimary, marginBottom: 8 }}>Addenda AES</h2>
      <p style={{ color: colors.textSecondary, fontSize: 14, marginBottom: 24 }}>Agrega información adicional requerida por clientes específicos al XML del CFDI.</p>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {[
          { nombre: "Walmart / Sam's Club", campos: ["NumProveedor", "OrdenCompra", "Departamento"], activa: true },
          { nombre: "FEMSA / OXXO", campos: ["CentroLogístico", "ClaveArticulo", "NumPedido"], activa: true },
          { nombre: "Liverpool", campos: ["CodigoProveedor", "Sucursal", "FolioRequisicion"], activa: false },
          { nombre: "Soriana", campos: ["NumProveedor", "ClaveArticulo", "Almacen"], activa: false },
        ].map(a => (
          <div key={a.nombre} style={{ background: colors.card, border: `1px solid ${a.activa ? colors.accentBorder : colors.border}`, borderRadius: 12, padding: 20, opacity: a.activa ? 1 : 0.65 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: colors.textPrimary }}>{a.nombre}</div>
              <div style={{ background: a.activa ? colors.accentSoft : colors.surface, color: a.activa ? colors.accentBorder : colors.textMuted, fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 20 }}>
                {a.activa ? "Activa" : "Inactiva"}
              </div>
            </div>
            <div style={{ marginBottom: 14 }}>
              {a.campos.map(c => <span key={c} style={{ display: "inline-block", background: colors.surface, border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 11, padding: "3px 8px", margin: "2px 4px 2px 0", color: colors.textSecondary, fontFamily: "monospace" }}>{c}</span>)}
            </div>
            <button onClick={() => alert(`GET /addenda/${a.nombre.toLowerCase()}/schema`)} style={{ fontSize: 12, padding: "7px 14px", borderRadius: 7, border: `1px solid ${colors.border}`, background: "transparent", cursor: "pointer", color: colors.textSecondary }}>
              {a.activa ? "Configurar campos" : "Activar addenda"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function ReporteMensual() {
  const meses = ["Ene", "Feb", "Mar", "Abr", "May"];
  const valores = [210000, 345000, 289000, 420000, 302450];
  const maxVal = Math.max(...valores);
  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 700, color: colors.textPrimary, marginBottom: 20 }}>Reporte Mensual</h2>
      <div style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: 12, padding: 24 }}>
        <div style={{ fontSize: 13, color: colors.textMuted, marginBottom: 16, textTransform: "uppercase", letterSpacing: "0.06em" }}>Facturación 2025 · Enero – Mayo</div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 16, height: 160, padding: "0 8px" }}>
          {meses.map((m, i) => (
            <div key={m} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
              <div style={{ fontSize: 11, color: colors.textMuted }}>{fmt(valores[i]).replace("MX$", "").trim()}</div>
              <div style={{ width: "100%", background: i === 4 ? colors.accent : colors.primary, borderRadius: "6px 6px 0 0", height: `${(valores[i] / maxVal) * 120}px`, opacity: i === 4 ? 1 : 0.75, transition: "height 0.4s" }} />
              <div style={{ fontSize: 12, color: colors.textSecondary, fontWeight: i === 4 ? 700 : 400 }}>{m}</div>
            </div>
          ))}
        </div>
        <div style={{ borderTop: `1px solid ${colors.border}`, marginTop: 20, paddingTop: 16, display: "flex", gap: 32 }}>
          <div><div style={{ fontSize: 11, color: colors.textMuted, marginBottom: 4 }}>TOTAL ACUMULADO</div><div style={{ fontSize: 20, fontWeight: 700, color: colors.textPrimary }}>{fmt(valores.reduce((a, b) => a + b, 0))}</div></div>
          <div><div style={{ fontSize: 11, color: colors.textMuted, marginBottom: 4 }}>FACTURAS EMITIDAS</div><div style={{ fontSize: 20, fontWeight: 700, color: colors.textPrimary }}>127</div></div>
          <div><div style={{ fontSize: 11, color: colors.textMuted, marginBottom: 4 }}>PROMEDIO</div><div style={{ fontSize: 20, fontWeight: 700, color: colors.textPrimary }}>{fmt(valores.reduce((a, b) => a + b, 0) / valores.length)}</div></div>
        </div>
        <button onClick={() => alert("GET /reportes/mensual?format=xlsx")} style={{ marginTop: 14, background: "transparent", border: `1px solid ${colors.border}`, borderRadius: 8, padding: "9px 18px", fontSize: 13, cursor: "pointer", color: colors.textSecondary }}>
          Descargar Excel →
        </button>
      </div>
    </div>
  );
}

function PlaceholderView({ title }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: 300, color: colors.textMuted }}>
      <div style={{ fontSize: 40, marginBottom: 16 }}>🚧</div>
      <div style={{ fontSize: 16, fontWeight: 600, color: colors.textSecondary }}>{title}</div>
      <div style={{ fontSize: 13, marginTop: 6 }}>Conecta el microservicio para habilitar esta vista</div>
    </div>
  );
}

const viewMap = {
  nueva: <NuevaFactura />,
  generadas: <FacturasGeneradas />,
  recibidas: <PlaceholderView title="Facturas Recibidas" />,
  reporte: <ReporteMensual />,
  emisores: <Emisores />,
  clientes: <Clientes />,
  usuarios: <PlaceholderView title="Usuarios" />,
  series: <PlaceholderView title="Series y Folios" />,
  config: <PlaceholderView title="Configuración" />,
  addenda: <AddendaAES />,
};

const sidebarLabels = {
  nueva: "Nueva Factura", generadas: "Generadas", recibidas: "Recibidas", reporte: "Reporte Mensual",
  emisores: "Emisores", clientes: "Clientes", usuarios: "Usuarios", series: "Series", config: "Configuración", addenda: "Addenda AES",
};

// ─── App shell ──────────────────────────────────────────────────────────────────
export default function App() {
  const [active, setActive] = useState("generadas");
  const [expanded, setExpanded] = useState({ facturas: true, admin: true });

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "'Inter', system-ui, sans-serif", background: colors.surface, color: colors.textPrimary }}>
      {/* Sidebar */}
      <aside style={{ width: 240, background: colors.primary, display: "flex", flexDirection: "column", flexShrink: 0 }}>
        <div style={{ padding: "22px 20px 18px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: colors.accent, letterSpacing: "0.1em", textTransform: "uppercase" }}>CFDI · AES</div>
          <div style={{ fontSize: 14, fontWeight: 600, color: "rgba(255,255,255,0.9)", marginTop: 2 }}>Portal de Facturación</div>
        </div>
        <nav style={{ flex: 1, padding: "12px 0", overflowY: "auto" }}>
          {navItems.map(item => (
            <div key={item.id}>
              <div onClick={() => item.children.length && setExpanded(e => ({ ...e, [item.id]: !e[item.id] }))}
                style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 20px", cursor: item.children.length ? "pointer" : "default", color: "rgba(255,255,255,0.7)", fontSize: 13, fontWeight: 600, userSelect: "none" }}>
                <span>{item.icon}</span>
                <span style={{ flex: 1 }}>{item.label}</span>
                {item.children.length > 0 && <span style={{ fontSize: 10, opacity: 0.5 }}>{expanded[item.id] ? "▾" : "▸"}</span>}
              </div>
              {item.id === "addenda" && (
                <div onClick={() => setActive("addenda")}
                  style={{ padding: "7px 20px 7px 40px", cursor: "pointer", fontSize: 13, color: active === "addenda" ? colors.accent : "rgba(255,255,255,0.55)", background: active === "addenda" ? "rgba(0,200,150,0.1)" : "transparent", borderLeft: active === "addenda" ? `2px solid ${colors.accent}` : "2px solid transparent" }}>
                  Addenda AES
                </div>
              )}
              {expanded[item.id] && item.children.map(child => (
                <div key={child} onClick={() => setActive(child)}
                  style={{ padding: "7px 20px 7px 40px", cursor: "pointer", fontSize: 13, color: active === child ? colors.accent : "rgba(255,255,255,0.55)", background: active === child ? "rgba(0,200,150,0.1)" : "transparent", borderLeft: active === child ? `2px solid ${colors.accent}` : "2px solid transparent", transition: "all 0.15s" }}>
                  {sidebarLabels[child]}
                </div>
              ))}
            </div>
          ))}
        </nav>
        <div style={{ padding: "16px 20px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>v2.0 · Microservicios</div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.25)", marginTop: 2 }}>5 servicios activos</div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Topbar */}
        <header style={{ background: colors.card, borderBottom: `1px solid ${colors.border}`, padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div>
            <div style={{ fontSize: 13, color: colors.textMuted }}>Bienvenido</div>
            <div style={{ fontSize: 15, fontWeight: 600, color: colors.textPrimary }}>Distribuidora Nacional SA de CV</div>
          </div>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <div style={{ fontSize: 12, color: colors.textMuted }}>RFC: DNS010101AAA</div>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: colors.primary, display: "flex", alignItems: "center", justifyContent: "center", color: colors.accent, fontWeight: 700, fontSize: 13 }}>DN</div>
          </div>
        </header>
        {/* Content */}
        <div style={{ flex: 1, overflowY: "auto", padding: "28px 32px" }}>
          {viewMap[active] || <PlaceholderView title={sidebarLabels[active]} />}
        </div>
      </main>
    </div>
  );
}
