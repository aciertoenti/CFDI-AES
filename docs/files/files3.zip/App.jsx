// ─── App.jsx ──────────────────────────────────────────────────────────────────
// CFDI-AES · Frontend completo conectado a microservicios
// Hooks IA: useDocumentExtractor, useFiscalChat, useAnomalias, useConciliacion
// ──────────────────────────────────────────────────────────────────────────────

import { useState, useEffect, useCallback, useRef } from "react";

// ═══════════════════════════════════════════════════════════════════════════════
// HOOKS IA (inline — en producción importar desde ./hooks/useIA.js)
// ═══════════════════════════════════════════════════════════════════════════════

const IA_BASE = "http://localhost:8006";
const API_BASE = "http://localhost:8000";

function useDocumentExtractor() {
  const [loading, setLoading]   = useState(false);
  const [result,  setResult]    = useState(null);
  const [error,   setError]     = useState(null);
  const [steps,   setSteps]     = useState([]);

  const extraer = useCallback(async (file) => {
    setLoading(true); setError(null); setResult(null); setSteps([]);
    const labels = ["Leyendo documento…","IA identificando campos fiscales…","Validando RFC en SAT…","Construyendo borrador CFDI…"];
    labels.forEach((l, i) => setTimeout(() => setSteps(p => [...p, l]), i * 900));
    try {
      const fd = new FormData(); fd.append("file", file);
      const res = await fetch(`${IA_BASE}/ia/extraer-documento`, { method: "POST", body: fd });
      if (!res.ok) throw new Error((await res.json()).detail || "Error");
      const data = await res.json(); setResult(data); return data;
    } catch(e) { setError(e.message); } finally { setLoading(false); }
  }, []);
  return { extraer, loading, result, error, steps };
}

function useFiscalChat() {
  const [messages,  setMessages]  = useState([]);
  const [streaming, setStreaming] = useState(false);
  const abortRef = useRef(null);

  const send = useCallback(async (text, ctx = {}) => {
    const history = [...messages, { role: "user", content: text }];
    setMessages([...history, { role: "assistant", content: "" }]);
    setStreaming(true);
    abortRef.current = new AbortController();
    try {
      const res = await fetch(`${IA_BASE}/ia/chat/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: abortRef.current.signal,
        body: JSON.stringify({ messages: history, contexto_cuenta: ctx }),
      });
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n"); buf = lines.pop();
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const raw = line.slice(6).trim();
          if (raw === "[DONE]") break;
          try {
            const { token } = JSON.parse(raw);
            setMessages(p => { const u=[...p]; u[u.length-1]={role:"assistant",content:u[u.length-1].content+token}; return u; });
          } catch {}
        }
      }
    } catch(e) { if (e.name !== "AbortError") setMessages(p => p.slice(0,-1)); }
    finally { setStreaming(false); }
  }, [messages]);

  const reset = () => setMessages([]);
  const abort = () => { abortRef.current?.abort(); setStreaming(false); };
  return { messages, send, streaming, reset, abort };
}

function useAnomalias() {
  const [anomalias, setAnomalias] = useState([]);
  const [loading, setLoading]     = useState(false);

  const detectar = useCallback(async (facturas, pagos=[]) => {
    setLoading(true);
    try {
      const res = await fetch(`${IA_BASE}/ia/anomalias`, {
        method: "POST", headers: { "Content-Type":"application/json" },
        body: JSON.stringify({ facturas, pagos_bancarios: pagos }),
      });
      const data = await res.json(); setAnomalias(data); return data;
    } finally { setLoading(false); }
  }, []);
  return { anomalias, detectar, loading };
}

// ═══════════════════════════════════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════════════════════════════════

const C = {
  primary:"#0A2540", accent:"#00C896", accentSoft:"#E6FAF5", accentBorder:"#00A87E",
  surface:"#F7F9FC", card:"#FFFFFF", border:"#E4E9F0",
  text:"#0A2540", textSec:"#5A6B7E", textMuted:"#8A9BB0",
  danger:"#E53E3E", dangerSoft:"#FFF5F5",
  warn:"#DD6B20",  warnSoft:"#FFFAF0",
  info:"#2B6CB0",  infoSoft:"#EBF8FF",
};

const fmt = n => new Intl.NumberFormat("es-MX",{style:"currency",currency:"MXN"}).format(n);

// ─── Mock data ─────────────────────────────────────────────────────────────────
const FACTURAS = [
  {folio:"A-0127",receptor:"Coppel SA de CV",total:77600,fecha:"2025-05-19",estado:"Vigente",uuid:"WXY7-ZAB8"},
  {folio:"A-0126",receptor:"OXXO Gas SA de CV",total:32100,fecha:"2025-05-16",estado:"Vigente",uuid:"KLM3-NOP4"},
  {folio:"A-0041",receptor:"Walmart de México",total:89300,fecha:"2025-05-12",estado:"Alerta",uuid:"MNO5-PQR6"},
  {folio:"A-0039",receptor:"FEMSA",total:124750,fecha:"2025-03-14",estado:"Vencida",uuid:"ABC1-DEF2"},
  {folio:"A-0003",receptor:"Tiendas Chedraui",total:9800,fecha:"2025-05-14",estado:"Cancelada",uuid:"YZA9-BCD0"},
];
const CLIENTES = [
  {nombre:"Comercial Mexicana SA",rfc:"CME900101AA1",email:"cfdi@comer.mx",credito:500000},
  {nombre:"Grupo Industrial FEMSA",rfc:"GIF850601BB2",email:"facturas@femsa.mx",credito:2000000},
  {nombre:"Tiendas Chedraui SA",rfc:"TCH780401CC3",email:"pagos@chedraui.mx",credito:800000},
  {nombre:"OXXO Gas SA de CV",rfc:"OGS920301DD4",email:"fiscal@oxxo.mx",credito:350000},
];
const EMISOR = {razon:"Distribuidora Nacional SA de CV",rfc:"DNS010101AAA",regimen:"601 – General de Ley Personas Morales",cp:"06600",csd:"Activo"};
const CUENTA_CTX = {
  iva_pendiente:38640, facturas_vigentes:4, facturas_vencidas:1,
  total_mayo:302450, cuentas_por_cobrar:246150,
  clientes_riesgo:[{nombre:"Liverpool",rfc:"LIV6809111A0",motivo:"EFOS SAT"}],
  proximo_vencimiento_iva:"2025-06-17",
};

const NAV = [
  {id:"facturas",label:"Mis Facturas",icon:"📄",children:["nueva","generadas","recibidas","reporte"]},
  {id:"ia",label:"IA",icon:"🤖",children:["lector","chat","anomalias","conciliacion"]},
  {id:"admin",label:"Administración",icon:"⚙️",children:["emisores","clientes","usuarios","series"]},
  {id:"addenda",label:"Addenda AES",icon:"🔗",children:[]},
];

const LABELS = {
  nueva:"Nueva Factura",generadas:"Generadas",recibidas:"Recibidas",reporte:"Reporte Mensual",
  lector:"Lector de Documentos",chat:"Chat Fiscal",anomalias:"Anomalías IA",conciliacion:"Conciliación",
  emisores:"Emisores",clientes:"Clientes",usuarios:"Usuarios",series:"Series",
  addenda:"Addenda AES",
};

// ═══════════════════════════════════════════════════════════════════════════════
// UI ATOMS
// ═══════════════════════════════════════════════════════════════════════════════

function Badge({estado}){
  const map={
    Vigente:{bg:"#E6FAF5",c:"#0A6B4A"},Vencida:{bg:"#FFF5F5",c:"#9B2C2C"},
    Cancelada:{bg:"#FFF5F5",c:"#9B2C2C"},Pendiente:{bg:"#FFFAF0",c:"#744210"},
    Alerta:{bg:"#FFFAF0",c:"#744210"},
  };
  const s=map[estado]||map.Pendiente;
  return <span style={{background:s.bg,color:s.c,fontSize:11,fontWeight:600,padding:"3px 10px",borderRadius:20}}>{estado}</span>;
}

function KPICard({label,value,sub,dark}){
  return (
    <div style={{background:dark?C.primary:C.card,border:`1px solid ${dark?"transparent":C.border}`,borderRadius:12,padding:"16px 18px",flex:1,minWidth:130}}>
      <div style={{fontSize:11,color:dark?"rgba(255,255,255,.5)":C.textMuted,marginBottom:6,textTransform:"uppercase",letterSpacing:"0.06em"}}>{label}</div>
      <div style={{fontSize:24,fontWeight:700,color:dark?C.accent:C.text,lineHeight:1}}>{value}</div>
      {sub&&<div style={{fontSize:11,color:dark?"rgba(255,255,255,.4)":C.textMuted,marginTop:4}}>{sub}</div>}
    </div>
  );
}

function Card({children,style={}}){
  return <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:12,padding:20,...style}}>{children}</div>;
}

function Btn({children,variant="primary",onClick,style={}}){
  const base={borderRadius:8,padding:"10px 20px",fontSize:13,fontWeight:600,cursor:"pointer",border:"none",...style};
  const styles={
    primary:{...base,background:C.primary,color:C.accent},
    secondary:{...base,background:"transparent",color:C.textSec,border:`1px solid ${C.border}`},
    accent:{...base,background:C.accent,color:"#fff"},
  };
  return <button style={styles[variant]||styles.primary} onClick={onClick}>{children}</button>;
}

// ═══════════════════════════════════════════════════════════════════════════════
// IA · VISTA 1: LECTOR DE DOCUMENTOS
// ═══════════════════════════════════════════════════════════════════════════════

function LectorDocumentos(){
  const {extraer,loading,result,error,steps} = useDocumentExtractor();
  const [dragging,setDragging] = useState(false);
  const [file,setFile]         = useState(null);
  const inputRef               = useRef();

  const handleFile = f => { setFile(f); extraer(f); };
  const onDrop = e => { e.preventDefault(); setDragging(false); const f=e.dataTransfer.files[0]; if(f) handleFile(f); };

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <div>
          <h2 style={{fontSize:22,fontWeight:700,color:C.text}}>Lector de documentos IA</h2>
          <p style={{color:C.textSec,fontSize:14,marginTop:2}}>Sube una orden de compra, cotización o nota de entrega — la IA extrae los datos y genera el CFDI.</p>
        </div>
        <span style={{marginLeft:"auto",fontSize:10,fontWeight:600,padding:"4px 10px",borderRadius:12,background:"#E6FAF5",color:"#0A6B4A"}}>● Modelo activo</span>
      </div>

      {!file && (
        <div
          onDrop={onDrop} onDragOver={e=>{e.preventDefault();setDragging(true);}} onDragLeave={()=>setDragging(false)}
          onClick={()=>inputRef.current.click()}
          style={{border:`2px dashed ${dragging?C.accent:C.border}`,borderRadius:12,padding:"48px 24px",textAlign:"center",cursor:"pointer",background:dragging?C.accentSoft:"transparent",transition:"all .2s"}}
        >
          <div style={{fontSize:40,marginBottom:12}}>📄</div>
          <div style={{fontSize:15,fontWeight:600,color:C.text,marginBottom:4}}>Arrastra tu documento aquí</div>
          <div style={{fontSize:13,color:C.textMuted}}>PDF · XML · JPG · PNG — orden de compra, cotización, nota de entrega</div>
          <input ref={inputRef} type="file" accept=".pdf,.jpg,.jpeg,.png,.xml" style={{display:"none"}} onChange={e=>e.target.files[0]&&handleFile(e.target.files[0])}/>
        </div>
      )}

      {loading && (
        <Card style={{marginTop:16}}>
          <div style={{fontSize:12,color:C.textMuted,marginBottom:4}}>Procesando: {file?.name}</div>
          <div style={{height:4,background:C.surface,borderRadius:2,overflow:"hidden",marginBottom:16}}>
            <div style={{height:"100%",background:C.accent,borderRadius:2,width:`${Math.min((steps.length/4)*100,95)}%`,transition:"width .5s"}}/>
          </div>
          {steps.map((s,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
              <span style={{fontSize:16}}>✓</span>
              <span style={{fontSize:13,color:C.textSec}}>{s}</span>
              <span style={{marginLeft:"auto",fontSize:11,color:C.textMuted}}>{(0.6+i*0.4).toFixed(1)}s</span>
            </div>
          ))}
        </Card>
      )}

      {error && (
        <Card style={{marginTop:16,borderColor:C.danger,background:C.dangerSoft}}>
          <div style={{fontSize:13,color:C.danger}}>⚠ {error}</div>
          <Btn variant="secondary" onClick={()=>setFile(null)} style={{marginTop:10}}>Intentar con otro archivo</Btn>
        </Card>
      )}

      {result && (
        <div style={{marginTop:16}}>
          <Card>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
              <div style={{fontSize:13,fontWeight:700,color:C.text,textTransform:"uppercase",letterSpacing:"0.06em"}}>Datos extraídos por IA</div>
              <span style={{fontSize:11,fontWeight:600,color:"#0A6B4A"}}>✓ {Math.round((result.confianza?.general||0.95)*100)}% confianza</span>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {[
                ["Receptor",result.receptor_nombre],
                ["RFC",result.receptor_rfc],
                ["Uso CFDI",result.receptor_uso_cfdi],
                ["Método pago",result.metodo_pago],
                ["Orden",result.numero_orden],
                ["Addenda",result.addenda_detectada||"—"],
              ].map(([l,v])=>(
                <div key={l} style={{background:C.surface,borderRadius:8,padding:"10px 12px",position:"relative"}}>
                  <div style={{fontSize:10,color:C.textMuted,textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:3}}>{l}</div>
                  <div style={{fontSize:13,fontWeight:600,color:C.text}}>{v||"—"}</div>
                  <span style={{position:"absolute",top:8,right:8,fontSize:9,fontWeight:600,padding:"2px 6px",borderRadius:8,background:"#EBF8FF",color:"#2B6CB0"}}>IA</span>
                  {result.confianza?.campos_inciertos?.includes(l.toLowerCase().replace(" ","_"))&&
                    <div style={{fontSize:10,color:C.warn,marginTop:2}}>⚠ Verificar</div>
                  }
                </div>
              ))}
            </div>
            {result.conceptos?.length>0&&(
              <div style={{marginTop:14,paddingTop:14,borderTop:`1px solid ${C.border}`}}>
                <div style={{fontSize:11,color:C.textMuted,marginBottom:8,textTransform:"uppercase",letterSpacing:"0.06em"}}>Conceptos ({result.conceptos.length})</div>
                {result.conceptos.map((c,i)=>(
                  <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:`1px solid ${C.border}`,fontSize:13}}>
                    <span style={{color:C.textSec}}>{c.descripcion}</span>
                    <span style={{fontWeight:600,color:C.text}}>{fmt((c.cantidad||0)*(c.precio_unitario||0))}</span>
                  </div>
                ))}
                <div style={{display:"flex",justifyContent:"flex-end",paddingTop:10,gap:8}}>
                  <span style={{fontSize:13,color:C.textMuted}}>Total estimado:</span>
                  <span style={{fontSize:16,fontWeight:700,color:C.accent}}>
                    {fmt(result.conceptos.reduce((s,c)=>s+(c.cantidad||0)*(c.precio_unitario||0)*(1+(c.iva_tasa||0.16)),0))}
                  </span>
                </div>
              </div>
            )}
          </Card>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginTop:10}}>
            <Btn onClick={()=>alert(`POST ${API_BASE}/facturas/timbrar con datos extraídos`)}>Timbrar este CFDI →</Btn>
            <Btn variant="secondary" onClick={()=>setFile(null)}>Procesar otro documento</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// IA · VISTA 2: CHAT FISCAL
// ═══════════════════════════════════════════════════════════════════════════════

const SUGERENCIAS = [
  "¿Cuánto IVA tengo pendiente de pagar?",
  "¿Qué clientes tienen RFC en riesgo ante el SAT?",
  "¿Cuánto me deben mis clientes en total?",
  "Genera un resumen ejecutivo de mayo",
  "¿Qué facturas vencen esta semana?",
];

function ChatFiscal(){
  const {messages,send,streaming,reset,abort} = useFiscalChat();
  const [input,setInput] = useState("");
  const bottomRef        = useRef();

  useEffect(()=>{ bottomRef.current?.scrollIntoView({behavior:"smooth"}); },[messages]);

  const submit = () => { if(!input.trim()||streaming) return; send(input.trim(),CUENTA_CTX); setInput(""); };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 140px)",gap:12}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div>
          <h2 style={{fontSize:22,fontWeight:700,color:C.text}}>Chat fiscal IA</h2>
          <p style={{fontSize:13,color:C.textSec,marginTop:2}}>Conectado a tu cuenta · RFC {EMISOR.rfc}</p>
        </div>
        <div style={{display:"flex",gap:8}}>
          {streaming&&<Btn variant="secondary" onClick={abort} style={{fontSize:12,padding:"6px 14px"}}>Detener</Btn>}
          <Btn variant="secondary" onClick={reset} style={{fontSize:12,padding:"6px 14px"}}>Nueva conversación</Btn>
        </div>
      </div>

      <Card style={{flex:1,overflowY:"auto",padding:16,display:"flex",flexDirection:"column",gap:10}}>
        {messages.length===0&&(
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:16}}>
            <div style={{width:52,height:52,borderRadius:14,background:C.primary,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>🤖</div>
            <div style={{fontSize:15,fontWeight:600,color:C.text}}>¿En qué te ayudo hoy?</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:8,justifyContent:"center",maxWidth:460}}>
              {SUGERENCIAS.map(s=>(
                <button key={s} onClick={()=>send(s,CUENTA_CTX)}
                  style={{fontSize:12,padding:"7px 14px",borderRadius:20,border:`1px solid ${C.border}`,background:C.surface,color:C.textSec,cursor:"pointer"}}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m,i)=>(
          <div key={i} style={{display:"flex",gap:8,justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
            {m.role==="assistant"&&<div style={{width:28,height:28,borderRadius:8,background:C.primary,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0}}>🤖</div>}
            <div style={{
              maxWidth:"80%",padding:"10px 14px",borderRadius:m.role==="user"?"12px 4px 12px 12px":"4px 12px 12px 12px",
              background:m.role==="user"?C.primary:C.surface,
              color:m.role==="user"?"#E8F4FF":C.text,
              fontSize:13,lineHeight:1.6,whiteSpace:"pre-wrap",
            }}>
              {m.content||<span style={{opacity:.4}}>●●●</span>}
            </div>
            {m.role==="user"&&<div style={{width:28,height:28,borderRadius:"50%",background:C.surface,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0}}>👤</div>}
          </div>
        ))}
        <div ref={bottomRef}/>
      </Card>

      <div style={{display:"flex",gap:8}}>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()}
          placeholder="Pregunta sobre IVA, clientes, facturas, SAT…"
          style={{flex:1,border:`1px solid ${C.border}`,borderRadius:8,padding:"10px 14px",fontSize:13,color:C.text,background:C.card}}
        />
        <Btn onClick={submit} style={{padding:"10px 18px"}}>Enviar →</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// IA · VISTA 3: ANOMALÍAS
// ═══════════════════════════════════════════════════════════════════════════════

function Anomalias(){
  const {anomalias,detectar,loading} = useAnomalias();
  const [ran,setRan] = useState(false);

  const correr = async () => { await detectar(FACTURAS,[]); setRan(true); };

  const sevColor = {alta:{bg:C.dangerSoft,c:C.danger},media:{bg:C.warnSoft,c:C.warn},baja:{bg:"#EBF8FF",c:C.info}};

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
        <div>
          <h2 style={{fontSize:22,fontWeight:700,color:C.text}}>Anomalías detectadas por IA</h2>
          <p style={{fontSize:13,color:C.textSec,marginTop:2}}>Análisis automático de tus facturas y pagos en busca de riesgos.</p>
        </div>
        <Btn onClick={correr} style={{opacity:loading?.5:1}}>
          {loading?"Analizando…":"Analizar ahora →"}
        </Btn>
      </div>

      {!ran&&!loading&&(
        <Card style={{textAlign:"center",padding:48}}>
          <div style={{fontSize:40,marginBottom:12}}>🔍</div>
          <div style={{fontSize:15,fontWeight:600,color:C.text,marginBottom:6}}>Sin análisis todavía</div>
          <div style={{fontSize:13,color:C.textMuted}}>Haz clic en "Analizar ahora" para que la IA revise tus facturas.</div>
        </Card>
      )}

      {loading&&(
        <Card style={{textAlign:"center",padding:40}}>
          <div style={{fontSize:32,marginBottom:12,animation:"spin 1s linear infinite"}}>⚙️</div>
          <div style={{fontSize:14,color:C.textSec}}>La IA está revisando tus facturas y pagos…</div>
        </Card>
      )}

      {ran&&!loading&&anomalias.length===0&&(
        <Card style={{textAlign:"center",padding:48}}>
          <div style={{fontSize:40,marginBottom:12}}>✅</div>
          <div style={{fontSize:15,fontWeight:600,color:C.text}}>Sin anomalías detectadas</div>
          <div style={{fontSize:13,color:C.textMuted,marginTop:4}}>Todo en orden por el momento.</div>
        </Card>
      )}

      {anomalias.map((a,i)=>{
        const s=sevColor[a.severidad]||sevColor.baja;
        return (
          <Card key={i} style={{marginBottom:10,borderLeft:`3px solid ${s.c}`}}>
            <div style={{display:"flex",alignItems:"flex-start",gap:12}}>
              <div style={{width:34,height:34,borderRadius:8,background:s.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>
                {a.tipo==="pago_retrasado"?"⏰":a.tipo==="rfc_riesgo"?"🚫":a.tipo==="discrepancia_pago"?"⚡":"📋"}
              </div>
              <div style={{flex:1}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                  <span style={{fontSize:14,fontWeight:700,color:C.text}}>{a.titulo}</span>
                  <span style={{fontSize:10,fontWeight:600,padding:"2px 8px",borderRadius:10,background:s.bg,color:s.c}}>{a.severidad.toUpperCase()}</span>
                </div>
                <div style={{fontSize:13,color:C.textSec,marginBottom:6}}>{a.descripcion}</div>
                <div style={{fontSize:12,color:C.info,background:"#EBF8FF",padding:"6px 10px",borderRadius:6}}>
                  💡 {a.accion_recomendada}
                </div>
              </div>
              {a.monto_en_riesgo>0&&(
                <div style={{textAlign:"right",flexShrink:0}}>
                  <div style={{fontSize:11,color:C.textMuted}}>En riesgo</div>
                  <div style={{fontSize:15,fontWeight:700,color:C.danger}}>{fmt(a.monto_en_riesgo)}</div>
                </div>
              )}
            </div>
          </Card>
        );
      })}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// VISTAS EXISTENTES
// ═══════════════════════════════════════════════════════════════════════════════

function NuevaFactura(){
  const [form,setForm] = useState({receptor:"",rfc:"",concepto:"",cantidad:"",precio:"",iva:"16"});
  const sub  = (parseFloat(form.cantidad)||0)*(parseFloat(form.precio)||0);
  const total = sub*(1+parseFloat(form.iva)/100);
  return (
    <div>
      <h2 style={{fontSize:22,fontWeight:700,color:C.text,marginBottom:6}}>Nueva Factura CFDI 4.0</h2>
      <p style={{color:C.textSec,fontSize:14,marginBottom:24}}>O usa el <strong>Lector IA</strong> para subir una orden de compra y rellenar esto automáticamente.</p>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <Card>
          <div style={{fontSize:11,fontWeight:700,color:C.accent,letterSpacing:"0.08em",marginBottom:14,textTransform:"uppercase"}}>Emisor</div>
          {[["Razón social",EMISOR.razon],["RFC",EMISOR.rfc],["Régimen",EMISOR.regimen]].map(([l,v])=>(
            <div key={l} style={{marginBottom:12}}>
              <label style={{fontSize:12,color:C.textSec,display:"block",marginBottom:4}}>{l}</label>
              <input readOnly value={v} style={{width:"100%",border:`1px solid ${C.border}`,borderRadius:8,padding:"9px 12px",fontSize:13,color:C.text,background:C.surface,boxSizing:"border-box"}}/>
            </div>
          ))}
        </Card>
        <Card>
          <div style={{fontSize:11,fontWeight:700,color:C.accent,letterSpacing:"0.08em",marginBottom:14,textTransform:"uppercase"}}>Receptor</div>
          {[["Receptor","receptor"],["RFC","rfc"]].map(([l,k])=>(
            <div key={k} style={{marginBottom:12}}>
              <label style={{fontSize:12,color:C.textSec,display:"block",marginBottom:4}}>{l}</label>
              <input value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})} placeholder={`Ingresa ${l.toLowerCase()}`}
                style={{width:"100%",border:`1px solid ${C.border}`,borderRadius:8,padding:"9px 12px",fontSize:13,color:C.text,background:"#fff",boxSizing:"border-box"}}/>
            </div>
          ))}
          <div style={{marginBottom:12}}>
            <label style={{fontSize:12,color:C.textSec,display:"block",marginBottom:4}}>Uso CFDI</label>
            <select style={{width:"100%",border:`1px solid ${C.border}`,borderRadius:8,padding:"9px 12px",fontSize:13,color:C.text,background:"#fff",boxSizing:"border-box"}}>
              <option>G03 – Gastos en general</option><option>G01 – Adquisición de mercancías</option><option>P01 – Por definir</option>
            </select>
          </div>
        </Card>
        <Card style={{gridColumn:"1 / -1"}}>
          <div style={{fontSize:11,fontWeight:700,color:C.accent,letterSpacing:"0.08em",marginBottom:14,textTransform:"uppercase"}}>Conceptos</div>
          <div style={{display:"grid",gridTemplateColumns:"3fr 1fr 1fr 1fr",gap:12,marginBottom:12}}>
            {[["Descripción","concepto","text"],["Cantidad","cantidad","number"],["Precio unitario","precio","number"],["IVA %","iva","number"]].map(([l,k,t])=>(
              <div key={k}>
                <label style={{fontSize:12,color:C.textSec,display:"block",marginBottom:4}}>{l}</label>
                <input type={t} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})} placeholder={l}
                  style={{width:"100%",border:`1px solid ${C.border}`,borderRadius:8,padding:"9px 12px",fontSize:13,color:C.text,background:"#fff",boxSizing:"border-box"}}/>
              </div>
            ))}
          </div>
          <div style={{display:"flex",justifyContent:"flex-end",gap:32,paddingTop:14,borderTop:`1px solid ${C.border}`}}>
            {[["Subtotal",sub],["IVA",sub*(parseFloat(form.iva)/100)],["Total",total]].map(([l,v])=>(
              <div key={l} style={{textAlign:"right"}}>
                <div style={{fontSize:12,color:C.textMuted}}>{l}</div>
                <div style={{fontSize:l==="Total"?20:15,fontWeight:l==="Total"?700:500,color:l==="Total"?C.accent:C.text}}>{fmt(v)}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <div style={{marginTop:16,display:"flex",gap:10}}>
        <Btn onClick={()=>alert(`POST ${API_BASE}/facturas/timbrar`)}>Timbrar con PAC →</Btn>
        <Btn variant="secondary">Guardar borrador</Btn>
      </div>
    </div>
  );
}

function FacturasGeneradas(){
  const [q,setQ] = useState(""); const [filtro,setFiltro] = useState("Todas");
  const items = FACTURAS.filter(f=>(filtro==="Todas"||f.estado===filtro)&&(f.receptor.toLowerCase().includes(q.toLowerCase())||f.folio.includes(q)));
  return (
    <div>
      <h2 style={{fontSize:22,fontWeight:700,color:C.text,marginBottom:18}}>Facturas generadas</h2>
      <div style={{display:"flex",gap:12,marginBottom:20,flexWrap:"wrap"}}>
        <KPICard label="Total emitido" value={fmt(FACTURAS.reduce((s,f)=>s+f.total,0))} dark/>
        <KPICard label="Vigentes" value={FACTURAS.filter(f=>f.estado==="Vigente").length}/>
        <KPICard label="Vencidas" value={FACTURAS.filter(f=>f.estado==="Vencida").length}/>
        <KPICard label="Canceladas" value={FACTURAS.filter(f=>f.estado==="Cancelada").length}/>
      </div>
      <Card style={{padding:0,overflow:"hidden"}}>
        <div style={{padding:"12px 16px",borderBottom:`1px solid ${C.border}`,display:"flex",gap:10,flexWrap:"wrap",alignItems:"center"}}>
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar por folio o receptor…"
            style={{flex:1,border:`1px solid ${C.border}`,borderRadius:8,padding:"8px 12px",fontSize:13,color:C.text,background:C.surface,minWidth:180}}/>
          {["Todas","Vigente","Vencida","Cancelada","Alerta"].map(f=>(
            <button key={f} onClick={()=>setFiltro(f)}
              style={{fontSize:11,padding:"5px 12px",borderRadius:12,border:`1px solid ${filtro===f?C.accent:C.border}`,background:filtro===f?C.accentSoft:"transparent",color:filtro===f?C.accentBorder:C.textSec,cursor:"pointer"}}>
              {f}
            </button>
          ))}
        </div>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr style={{background:C.surface}}>
            {["Folio","Receptor","Fecha","Total","Estado","Acciones"].map(h=>(
              <th key={h} style={{padding:"10px 16px",textAlign:"left",fontSize:11,fontWeight:700,color:C.textMuted,textTransform:"uppercase",letterSpacing:"0.06em"}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>{items.map((f,i)=>(
            <tr key={f.folio} style={{borderTop:`1px solid ${C.border}`,background:i%2===0?"#fff":C.surface}}>
              <td style={{padding:"11px 16px",fontSize:13,fontWeight:600,color:C.primary,fontFamily:"monospace"}}>{f.folio}</td>
              <td style={{padding:"11px 16px",fontSize:13,color:C.text}}>{f.receptor}</td>
              <td style={{padding:"11px 16px",fontSize:13,color:C.textSec}}>{f.fecha}</td>
              <td style={{padding:"11px 16px",fontSize:13,fontWeight:600,color:C.text}}>{fmt(f.total)}</td>
              <td style={{padding:"11px 16px"}}><Badge estado={f.estado}/></td>
              <td style={{padding:"11px 16px"}}>
                <div style={{display:"flex",gap:6}}>
                  <button onClick={()=>alert(`GET ${API_BASE}/facturas/${f.uuid}/xml`)} style={{fontSize:11,padding:"4px 8px",borderRadius:6,border:`1px solid ${C.border}`,background:"transparent",cursor:"pointer",color:C.textSec}}>XML</button>
                  <button onClick={()=>alert(`GET ${API_BASE}/facturas/${f.uuid}/pdf`)} style={{fontSize:11,padding:"4px 8px",borderRadius:6,border:`1px solid ${C.border}`,background:"transparent",cursor:"pointer",color:C.textSec}}>PDF</button>
                </div>
              </td>
            </tr>
          ))}</tbody>
        </table>
      </Card>
    </div>
  );
}

function Clientes(){
  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <h2 style={{fontSize:22,fontWeight:700,color:C.text}}>Clientes</h2>
        <Btn onClick={()=>alert(`POST ${API_BASE}/admin/clientes`)}>+ Nuevo cliente</Btn>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
        {CLIENTES.map(c=>(
          <Card key={c.rfc}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
              <div>
                <div style={{fontSize:15,fontWeight:600,color:C.text}}>{c.nombre}</div>
                <div style={{fontSize:12,color:C.textMuted,fontFamily:"monospace",marginTop:2}}>{c.rfc}</div>
              </div>
              <span style={{background:C.accentSoft,color:C.accentBorder,fontSize:11,fontWeight:600,padding:"3px 10px",borderRadius:20}}>Activo</span>
            </div>
            <div style={{fontSize:13,color:C.textSec,marginBottom:6}}>✉ {c.email}</div>
            <div style={{fontSize:13,color:C.textSec}}>Crédito: <strong style={{color:C.text}}>{fmt(c.credito)}</strong></div>
            <div style={{marginTop:12,display:"flex",gap:8}}>
              <button onClick={()=>alert(`PUT ${API_BASE}/admin/clientes/${c.rfc}`)} style={{fontSize:12,padding:"6px 12px",borderRadius:7,border:`1px solid ${C.border}`,background:"transparent",cursor:"pointer",color:C.textSec}}>Editar</button>
              <button onClick={()=>alert(`GET ${API_BASE}/facturas?receptor=${c.rfc}`)} style={{fontSize:12,padding:"6px 12px",borderRadius:7,border:`1px solid ${C.accentBorder}`,background:C.accentSoft,cursor:"pointer",color:C.accentBorder}}>Ver facturas</button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function ReporteMensual(){
  const meses=["Ene","Feb","Mar","Abr","May"]; const vals=[210000,345000,289000,420000,302450]; const maxV=420000;
  return (
    <div>
      <h2 style={{fontSize:22,fontWeight:700,color:C.text,marginBottom:20}}>Reporte mensual</h2>
      <Card>
        <div style={{fontSize:12,color:C.textMuted,marginBottom:14,textTransform:"uppercase",letterSpacing:"0.06em"}}>Facturación 2025 · Enero – Mayo</div>
        <div style={{display:"flex",alignItems:"flex-end",gap:14,height:160,padding:"0 8px"}}>
          {meses.map((m,i)=>(
            <div key={m} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:6}}>
              <div style={{fontSize:10,color:C.textMuted}}>{fmt(vals[i]).replace("MX$","").trim()}</div>
              <div style={{width:"100%",background:i===4?C.accent:C.primary,borderRadius:"6px 6px 0 0",height:`${(vals[i]/maxV)*120}px`,opacity:i===4?1:.7}}/>
              <div style={{fontSize:12,color:C.textSec,fontWeight:i===4?700:400}}>{m}</div>
            </div>
          ))}
        </div>
        <div style={{borderTop:`1px solid ${C.border}`,marginTop:16,paddingTop:14,display:"flex",gap:28}}>
          {[["Total acumulado",fmt(vals.reduce((a,b)=>a+b,0))],["CFDIs emitidos","127"],["Promedio",fmt(vals.reduce((a,b)=>a+b,0)/vals.length)]].map(([l,v])=>(
            <div key={l}><div style={{fontSize:11,color:C.textMuted,marginBottom:4}}>{l.toUpperCase()}</div><div style={{fontSize:18,fontWeight:700,color:C.text}}>{v}</div></div>
          ))}
        </div>
        <Btn variant="secondary" onClick={()=>alert(`GET ${API_BASE}/ia/resumen-ejecutivo`)} style={{marginTop:14}}>Descargar Excel →</Btn>
      </Card>
    </div>
  );
}

function Placeholder({title}){
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:300,color:C.textMuted}}>
      <div style={{fontSize:40,marginBottom:14}}>🚧</div>
      <div style={{fontSize:16,fontWeight:600,color:C.textSec}}>{title}</div>
      <div style={{fontSize:13,marginTop:6}}>Conecta el microservicio para habilitar esta vista</div>
    </div>
  );
}

const VIEWS = {
  nueva:<NuevaFactura/>, generadas:<FacturasGeneradas/>, recibidas:<Placeholder title="Facturas recibidas"/>,
  reporte:<ReporteMensual/>, lector:<LectorDocumentos/>, chat:<ChatFiscal/>,
  anomalias:<Anomalias/>, conciliacion:<Placeholder title="Conciliación bancaria"/>,
  emisores:<Placeholder title="Emisores"/>, clientes:<Clientes/>,
  usuarios:<Placeholder title="Usuarios"/>, series:<Placeholder title="Series y folios"/>,
  addenda:<Placeholder title="Addenda AES"/>,
};

// ═══════════════════════════════════════════════════════════════════════════════
// APP SHELL
// ═══════════════════════════════════════════════════════════════════════════════

export default function App(){
  const [active,setActive]   = useState("generadas");
  const [expanded,setExpanded] = useState({facturas:true,ia:true,admin:false});

  const toggle = id => setExpanded(e=>({...e,[id]:!e[id]}));

  return (
    <div style={{display:"flex",height:"100vh",fontFamily:"'Inter',system-ui,sans-serif",background:C.surface,color:C.text}}>
      {/* Sidebar */}
      <aside style={{width:232,background:C.primary,display:"flex",flexDirection:"column",flexShrink:0}}>
        <div style={{padding:"20px 18px 14px",borderBottom:"1px solid rgba(255,255,255,.08)"}}>
          <div style={{fontSize:11,fontWeight:700,color:C.accent,letterSpacing:"0.1em",textTransform:"uppercase"}}>CFDI · AES</div>
          <div style={{fontSize:13,fontWeight:600,color:"rgba(255,255,255,.9)",marginTop:2}}>Portal Inteligente</div>
        </div>
        <nav style={{flex:1,padding:"10px 0",overflowY:"auto"}}>
          {NAV.map(item=>(
            <div key={item.id}>
              <div onClick={()=>item.children.length&&toggle(item.id)}
                style={{display:"flex",alignItems:"center",gap:9,padding:"9px 18px",cursor:"pointer",color:"rgba(255,255,255,.7)",fontSize:13,fontWeight:600,userSelect:"none"}}>
                <span>{item.icon}</span>
                <span style={{flex:1}}>{item.label}</span>
                {item.id==="ia"&&<span style={{fontSize:9,padding:"2px 6px",borderRadius:8,background:"rgba(0,200,150,.2)",color:C.accent}}>IA</span>}
                {item.children.length>0&&<span style={{fontSize:10,opacity:.5}}>{expanded[item.id]?"▾":"▸"}</span>}
              </div>
              {item.id==="addenda"&&(
                <div onClick={()=>setActive("addenda")}
                  style={{padding:"7px 18px 7px 38px",cursor:"pointer",fontSize:13,color:active==="addenda"?C.accent:"rgba(255,255,255,.55)",background:active==="addenda"?"rgba(0,200,150,.1)":"transparent",borderLeft:active==="addenda"?`2px solid ${C.accent}`:"2px solid transparent"}}>
                  Addenda AES
                </div>
              )}
              {expanded[item.id]&&item.children.map(child=>(
                <div key={child} onClick={()=>setActive(child)}
                  style={{padding:"7px 18px 7px 38px",cursor:"pointer",fontSize:13,color:active===child?C.accent:"rgba(255,255,255,.55)",background:active===child?"rgba(0,200,150,.1)":"transparent",borderLeft:active===child?`2px solid ${C.accent}`:"2px solid transparent",transition:"all .15s"}}>
                  {LABELS[child]}
                </div>
              ))}
            </div>
          ))}
        </nav>
        <div style={{padding:"14px 18px",borderTop:"1px solid rgba(255,255,255,.08)"}}>
          <div style={{fontSize:11,color:"rgba(255,255,255,.35)"}}>v2.0 · 6 microservicios</div>
          <div style={{display:"flex",gap:4,marginTop:6,flexWrap:"wrap"}}>
            {["Facturación","Admin","IA","Auth"].map(s=>(
              <span key={s} style={{fontSize:9,padding:"2px 6px",borderRadius:6,background:"rgba(0,200,150,.15)",color:C.accent}}>{s}</span>
            ))}
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <header style={{background:C.card,borderBottom:`1px solid ${C.border}`,padding:"13px 28px",display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0}}>
          <div>
            <div style={{fontSize:12,color:C.textMuted}}>Bienvenido de vuelta</div>
            <div style={{fontSize:15,fontWeight:600,color:C.text}}>{EMISOR.razon}</div>
          </div>
          <div style={{display:"flex",gap:12,alignItems:"center"}}>
            <div style={{fontSize:12,color:C.textMuted}}>RFC: {EMISOR.rfc}</div>
            <div style={{position:"relative"}}>
              <div style={{width:8,height:8,borderRadius:"50%",background:C.danger,position:"absolute",top:-2,right:-2,border:"2px solid #fff"}}/>
              <span style={{fontSize:18,cursor:"pointer"}}>🔔</span>
            </div>
            <div style={{width:34,height:34,borderRadius:"50%",background:C.primary,display:"flex",alignItems:"center",justifyContent:"center",color:C.accent,fontWeight:700,fontSize:12}}>DN</div>
          </div>
        </header>
        <div style={{flex:1,overflowY:"auto",padding:"26px 30px"}}>
          {VIEWS[active]||<Placeholder title={LABELS[active]}/>}
        </div>
      </main>
    </div>
  );
}
